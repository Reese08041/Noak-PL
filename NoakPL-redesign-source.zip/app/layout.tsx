import type { Metadata } from "next";
import "./globals.css";
import "./revamp.css";

export const metadata: Metadata = {
  title: "NoakPL | Opportunities & Interview Prep",
  description: "Verified finance opportunities and interview preparation.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
